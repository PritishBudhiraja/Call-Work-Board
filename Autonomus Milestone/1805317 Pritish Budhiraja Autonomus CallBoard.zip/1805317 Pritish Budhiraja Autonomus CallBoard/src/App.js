import React from "react";

import CallWorkBoard from "../src/views/CallWorkBoard";

import "./App.css";
import "./App.css";

const App = () => {
  return <CallWorkBoard />;
};

export default App;
