import * as actionTypes from "./actionTypes";

export function showFreeda() {
  return {
    type: actionTypes.SHOW_FREEDA,
  };
}
